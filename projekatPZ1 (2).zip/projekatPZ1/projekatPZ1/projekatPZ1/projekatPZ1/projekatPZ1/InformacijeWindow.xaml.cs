﻿using projekatPZ1;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace projekatPZ1
{
    /// <summary>
    /// Interaction logic for prikazInformacija.xaml
    /// </summary>
    public partial class InformacijeWindow : Window
    {
        //---------Binding liste
        private static BindingList<Igraci> nbaIgraci = new BindingList<Igraci>();
        public static BindingList<Igraci> NBAIgraci { get => nbaIgraci; set => nbaIgraci = value; }
        
        

        public InformacijeWindow(int i)
        {
            Igraci igrac = DodajWindow.Igrac[i];
            NBAIgraci.Add(igrac);
            DataContext = this;
            InitializeComponent();
        }

        private void buttonExit_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void Window_Closing(object sender, CancelEventArgs e)
        {
            NBAIgraci.Clear();
        }

       
    }
}

