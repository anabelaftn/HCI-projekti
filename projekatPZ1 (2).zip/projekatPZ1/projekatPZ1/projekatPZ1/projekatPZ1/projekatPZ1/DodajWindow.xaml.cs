﻿using projekatPZ1;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;


namespace projekatPZ1
{

    public partial class DodajWindow : Window
    {
        //-----Liste za binding sa xaml-----
        public static BindingList<Igraci> Igrac { get; set; }

        private static BindingList<Igraci> cekiranje = new BindingList<Igraci>();
        public static BindingList<Igraci> Cekiranje { get => cekiranje; set => cekiranje = value; }  //get set

        public static  DataIO serializer = new DataIO(); //Serijalizacija

        private static  bool oznacen=false;

  


        public DodajWindow()
        {
            InitializeComponent();

            //Sluzi za xml fajl, rasparca na bajtove i onda salje posle

            Igrac = serializer.DeSerializeObject<BindingList<Igraci>>("Igraci.xml");

            

            //ako nema igraca napravi novo
            if (Igrac == null)
            {
                Igrac = new BindingList<Igraci>();
            }

            DataContext = this;

           

            //zabrana za korisnike
            if (promenljive.LogovanjeUspesno.Equals(promenljive.KorisnikUsername))
            {
                buttonObrisi.IsEnabled = false;
                buttonDodaj.IsEnabled = false;
            }
            
        }

        //------Dugme za dodavanje--------
        private void buttonDodaj_Click(object sender, RoutedEventArgs e)
        {
            DodavanjeWindow dodavanjeW = new DodavanjeWindow();
            dodavanjeW.ShowDialog();
        }

        //----------Dugme za brisanje-----------
        private void buttonObrisi_Click(object sender, RoutedEventArgs e)
        {
            for (int i = 0; i < cekiranje.Count; i++)   //Brise sve sto je cekirano
            {
                Igrac.Remove(cekiranje[i]);
            }

            for (int i = 0; i < cekiranje.Count; i++)
            {
                if (cekiranje[i] != null)
                {
                    string putanjaDoFajla = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, cekiranje[i].Fajl);
                    try
                    {
                        File.Delete(putanjaDoFajla);    
                    }
                    catch (IOException exp)
                    {
                        Console.WriteLine(exp.Message);
                    }
                }
            }
        
        }

        //---------Dugma  izadji-----------
        private void buttonIzadji_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }


        //Hiperlink
        private void Hyperlink_Click(object sender, RoutedEventArgs e)
        {
            if (promenljive.LogovanjeUspesno.Equals(promenljive.AdminUserName))
            {
                IzmeniWindow izmena = new IzmeniWindow(DataGridnbaIgraci.SelectedIndex);   //ono sto je oznaceno moze da se menja i salje se na izmeniwindow
                izmena.ShowDialog(); //omogucav aadminu izmenu
            }
            if (promenljive.LogovanjeUspesno.Equals(promenljive.KorisnikUsername))
            {
                InformacijeWindow prikaz = new InformacijeWindow(DataGridnbaIgraci.SelectedIndex);
                prikaz.ShowDialog();  //omogucava prikaz svih info
            }
        }


        private void DataGridnbaIgraci_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if(oznacen== true)
            {
                cekiranje.Add((Igraci)DataGridnbaIgraci.SelectedItem);
            }
        }

        private void chbCekiranje_MouseEnter(object sender, MouseEventArgs e)
        {
            oznacen = true;
        }

        private void Window_Closing(object sender, CancelEventArgs e)
        {
            serializer.SerializeObject<BindingList<Igraci>>(Igrac, "igraci.xml");
        }
    }
}
