﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace projekatPZ1
{
    [Serializable]
   public class Igraci
    {
        #region podaci
        private string klub;
        private string ime;
        private string prezime;
        private Int64 godinaRodjenja;
        private Int64 brojPoena;
        private Int64 brojUtakmica;
        private string slika;
        private string fajl = "";
        private DateTime datum;
        #endregion

        #region konstruktor
        public Igraci(string klub, string ime, string prezime, Int64 godinaRodjenja,
            Int64 brojPoena, Int64 brojUtakmica, string slika,
            string fajl, DateTime datum)
        {
            this.klub = klub;
            this.ime = ime;
            this.prezime = prezime;
            this.godinaRodjenja = godinaRodjenja;
            this.brojPoena = brojPoena;
            this.brojUtakmica = brojUtakmica;
            this.slika = slika;
            this.fajl = fajl;
            this.datum = datum;
        }
        #endregion

        public Igraci()
        { }

        #region setget
        public string Klub { get => klub; set => klub = value; }
        public string Ime { get => ime; set => ime = value; }
        public string Prezime { get => prezime; set => prezime = value; }
        public Int64 GodinaRodjenja { get => godinaRodjenja; set => godinaRodjenja = value; }
        public string Slika { get => slika; set => slika = value; }
        public string Fajl { get => fajl; set => fajl = value; }
        public System.DateTime Datum { get => datum; set => datum = value; }
        public Int64 BrojPoena { get => brojPoena; set => brojPoena = value; }
        public Int64 BrojUtakmica { get => brojUtakmica; set => brojUtakmica = value; }
        #endregion

       
    }
}
