﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetworkService.Model
{
    public class CheckBoxData
    {
        public string Naziv { get; set; }
        public bool IsChecked { get; set; }

        public CheckBoxData(string naziv, bool isChecked)
        {
            Naziv = naziv;
            IsChecked = isChecked;
        }
    }
}
