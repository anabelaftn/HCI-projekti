﻿using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace NetworkService.Model
{
   
    public static class DataBase  //glavna baza za celu apl
    {
        public static ObservableCollection<Generator> Generatori { get; set; } = new ObservableCollection<Generator>();

        public static ObservableCollection<TipGeneratora> TipoviGeneratora { get; set; } = new ObservableCollection<TipGeneratora>()
        {
			
			new TipGeneratora("Solarni Panel", "pack://application:,,,/Slike/SolarPanels.jpg"),
            new TipGeneratora("Vetro Generator", "pack://application:,,,/Slike/WindPowers.jpg")
        };

        public static Dictionary<string, Generator> CanvasObjects { get; set; } = new Dictionary<string, Generator>();

        static DataBase()
        {
            Generatori = new ObservableCollection<Generator>()
            {
                new Generator(1, "Generator_1", TipoviGeneratora[0]),
                new Generator(2, "Generator_2", TipoviGeneratora[1])
            };

            // SacuvaniGenerator.Add(Generatori);
        }
    }
}
