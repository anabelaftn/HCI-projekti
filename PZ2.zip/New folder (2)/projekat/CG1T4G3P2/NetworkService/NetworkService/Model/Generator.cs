﻿using NetworkService.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetworkService.Model
{
    public class Generator : BindableBase
    {
        #region Properties
        public static List<double> doubleList = new List<double>();
        private int id;
        public int ID
        {
            get { return id; }
            set
            {
                id = value;
                OnPropertyChanged("ID");
            }
        }


        private string naziv;
        public string Naziv
        {
            get { return naziv; }
            set
            {
                naziv = value;
                OnPropertyChanged("Naziv");
            }
        }

        private TipGeneratora tip;
        public TipGeneratora Tip
        {
            get { return tip; }
            set
            {
                tip = value;
                OnPropertyChanged("Tip");
            }
        }

        private double vrednost;
        public double Vrednost
        {
            get { return vrednost; }
            set
            {
                doubleList.Add(value);
                vrednost = value;
                ChartDataViewModel.SetFirstDotAndValue(ChartDataViewModel.CalculateElementRadius(value), value, naziv);
                OnPropertyChanged("Vrednost");
            }
        }

        #endregion


        #region Constructors

        public Generator() { }

        public Generator(int id, string naziv, TipGeneratora tip)
        {
            this.ID = id;
            this.Naziv = naziv;
            this.Tip = tip;
            Vrednost = 0;
        }

        public Generator(Generator g)
        {
            g = g ?? new Generator();
            this.ID = g.ID;
            this.Naziv = g.Naziv;
            this.Tip = g.Tip;
            //this.Tip.NazivTipa = g.tip.NazivTipa;
            //this.Tip.SlikaTipa = g.tip.SlikaTipa;
            this.Vrednost = g.Vrednost;
        }
        
        #endregion


        public override string ToString()
        {
            return ID + "-" + Naziv;
        }
    }
}
