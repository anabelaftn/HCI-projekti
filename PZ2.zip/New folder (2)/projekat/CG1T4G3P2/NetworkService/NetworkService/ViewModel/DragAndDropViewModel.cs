﻿using NetworkService.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace NetworkService.ViewModel
{
    public class DragAndDropViewModel : BindableBase
    {
        #region Sve sto mi treba
        private ListView listViewGenerator;
        public BindingList<Generator> Items { get; set; }

        public MyICommand<ListView> MLBUCommand { get; set; }
        public MyICommand<Generator> SCCommand { get; set; }
        public MyICommand<Canvas> DCommand { get; set; }
        public MyICommand<Canvas> FreeCommand { get; set; }
        public MyICommand<Canvas> LCommand { get; set; }
        public MyICommand<Canvas> SCommand { get; set; }
        public MyICommand<ListView> LLWCommand { get; set; }
        public List<Canvas> filledCanvases = new List<Canvas>(); //popunjeni kanvasi
        public static Generator draggedItem = null;
        private Grid _gridName;
        private bool dragging = false;
        private static bool exists = false;
        private int selectedIndex = 0;
        public ObservableCollection<LineModel> Lines { get; set; } //linije

        Dictionary<int, Generator> temp = new Dictionary<int, Generator>();

        private Canvas uzetCanvas;
        private bool izListe = false;
        public static Dictionary<int, Generator> ubaceniUMrezu = new Dictionary<int, Generator>();
        private Grid _mainCanvas;

        #endregion


        public Grid MainCanvas
        {
            get { return _mainCanvas; }
            set
            {
                if (_mainCanvas != value)
                {
                    _mainCanvas = value;
                    OnPropertyChanged(nameof(MainCanvas));
                }
            }
        }

        public UserControl CurrentUserControl { get; set; }
        public MyICommand FillOutCommand { get; set; } //oslobadjanje

        public int SelectedIndex    //oznacen slika u listi
        {
            get { return selectedIndex; }
            set
            {
                selectedIndex = value;
                OnPropertyChanged("SelectedIndex");
            }
        }

        /// <summary>
        /// Inicijalizacija stvari koje ce se koristiti 
        /// </summary>
        /// <param name="userControl"></param>

        public DragAndDropViewModel(UserControl userControl)       
        {
            Lines = new ObservableCollection<LineModel>();
            CurrentUserControl = userControl;
            foreach (Generator generator in DataBase.Generatori)
            {
                temp.Add(generator.ID, generator);
            }

            Items = new BindingList<Generator>();

            foreach (Generator generator1 in DataBase.Generatori)
            {
                exists = false;
                foreach (Generator generator2 in DataBase.CanvasObjects.Values)
                {
                    if (generator2.ID == generator1.ID)
                    {
                        exists = true;
                        break;
                    }
                }

                if (exists == false)
                    Items.Add(new Generator(generator1));
            }

            MLBUCommand = new MyICommand<ListView>(Pusti);
            SCCommand = new MyICommand<Generator>(Prevuci);
            DCommand = new MyICommand<Canvas>(Zauzmi);
            FreeCommand = new MyICommand<Canvas>(Oslobodi);
            LCommand = new MyICommand<Canvas>(OnLoad);
            SCommand = new MyICommand<Canvas>(UzmiCanvas);
            LLWCommand = new MyICommand<ListView>(OnLLW);
            FillOutCommand = new MyICommand(IzlistajSveOdjednom);
        }

        #region Prevlacenje iz canvasa u canvas

       
        /// <param name="canvas">Kliknut kanvas</param>


        private void UzmiCanvas(Canvas canvas)
        {
            
            if (canvas.Resources["taken"] != null)
            {
                draggedItem = DataBase.CanvasObjects[canvas.Name];

                if (!dragging)
                {
                    izListe = false;
                    dragging = true;
                    uzetCanvas = canvas;
                    DragDrop.DoDragDrop(canvas, draggedItem, DragDropEffects.Copy | DragDropEffects.Move);

                    canvas.Resources.Remove("taken");
                    filledCanvases.Remove(canvas);

                    ConnectCanvasesWithOneLine(filledCanvases);
                }
            }
        }

       
        /// Izvrsava se nakon prenosa kanvasa u drugi kanvas
       

        private void IzbrisiStariCanvas()
        {
            uzetCanvas.Background = (SolidColorBrush)new BrushConverter().ConvertFrom("#1F3044");
            DataBase.CanvasObjects.Remove(uzetCanvas.Name);
            uzetCanvas.Resources.Remove("taken");
            uzetCanvas = null;
        }

        #endregion


        //Ucitavaju se svi generatori

        /// <param name="listview"></param>

        public void OnLLW(ListView listview)
        {
            listViewGenerator = listview;
        }


        #region Ucitaj promene na kanvasu_ONLOAD

        //Ucitavanje zauzetih kanvasa na view
        /// <param name="c"></param>

        public void OnLoad(Canvas c)
        {
            if (DataBase.CanvasObjects.ContainsKey(c.Name))
            {
                BitmapImage logo = new BitmapImage();
                logo.BeginInit();
                logo.UriSource = new Uri(DataBase.CanvasObjects[c.Name].Tip.SlikaTipa);
                logo.EndInit();
                c.Background = new ImageBrush(logo);
                if (!c.Resources.Contains("taken"))
                {
                    c.Resources.Add("taken", true);
                    filledCanvases.Add(c);
                    ConnectCanvasesWithOneLine(filledCanvases);
                }
                ProveriVrednost(c);
            }
        }

        #endregion


        #region Oslobodi canvas

        /// <param name="canvas"></param>

        public void Oslobodi(Canvas canvas)
        {
            try
            {
                if (canvas.Resources["taken"] != null)
                {
                    canvas.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#1F3044")); ;
                    ((Border)canvas.Children[0]).BorderBrush = Brushes.Transparent;

                    foreach (Generator generator in DataBase.Generatori)
                    {
                        if (!Items.Contains(generator) && DataBase.CanvasObjects[canvas.Name].ID == generator.ID)
                        {
                            Items.Add(new Generator(generator));
                        }
                    }
                    canvas.Resources.Remove("taken");
                    filledCanvases.Remove(canvas);
                    DataBase.CanvasObjects.Remove(canvas.Name);
                    ConnectCanvasesWithOneLine(filledCanvases);
                }
            }
            catch (Exception) { }
        }

        #endregion


        #region Zauzmi canvas

        /// <param name="canvas"></param>

        public void Zauzmi(Canvas canvas)
        {

            if (draggedItem != null)
            {
                if (canvas.Resources["taken"] == null)
                {
                    BitmapImage logo = new BitmapImage();
                    logo.BeginInit();
                    logo.UriSource = new Uri(draggedItem.Tip.SlikaTipa);
                    logo.EndInit();
                    canvas.Background = new ImageBrush(logo);
                    //DataBase.CanvasObjects[canvas.Name] = draggedItem;
                    canvas.Resources.Add("taken", true);

                    filledCanvases.Add(canvas);
                    Grid grid = (Grid)CurrentUserControl.FindName("MainCanvas");


                    if (izListe)
                        Items.Remove(Items.Single(x => x.ID == draggedItem.ID));

                    if (izListe)
                    {
                        DataBase.CanvasObjects[canvas.Name] = draggedItem;
                        izListe = false;
                    }
                    else
                    {
                        DataBase.CanvasObjects[canvas.Name] = draggedItem;
                        IzbrisiStariCanvas();
                    }

                    SelectedIndex = 0;
                    ProveriVrednost(canvas);

                    ConnectCanvasesWithOneLine(filledCanvases);
                }
                dragging = false;
            }
        }

        #endregion


        #region Pusti klik

       
        /// <param name="lw"></param>

        public void Pusti(ListView lw)
        {
            draggedItem = null;
            lw.SelectedItem = null;
            dragging = false;
        }

        #endregion


        #region Prevuci objekat

       
        /// <param name="generator"></param>

        public void Prevuci(Generator generator)
        {
            if (!dragging)
            {
                dragging = true;
                izListe = true;
                draggedItem = new Generator(generator);
                DragDrop.DoDragDrop(listViewGenerator, draggedItem, DragDropEffects.Move);
            }
        }

        #endregion


        #region Izlistaj sve objekte na prazna polja-autofill

       

        private void IzlistajSveOdjednom()
        {
           
            List<int> GeneratorDelete = new List<int>();

            
            foreach (Generator generator in Items)
            {
               
                for (int i = 1; i <= 12; i++)  //ovde nalazim prvo slobodno mesto
                {
                    if (!DataBase.CanvasObjects.ContainsKey($"canvas{i}"))
                    {
                        DataBase.CanvasObjects.Add($"canvas{i}", generator);
                        GeneratorDelete.Add(generator.ID);
                        break;
                    }
                }
            }

            Items = new BindingList<Generator>(Items.Where(tp => !GeneratorDelete.Contains(tp.ID)).ToList()); //Brisem sve koji su ubaceni
            
            OnPropertyChanged("Items");

            
            for (int i = 1; i <= 12; i++)  //ucitavaju se promene na canvasima
            {
                Canvas canvas = (Canvas)CurrentUserControl.FindName($"canvas{i}");
                OnLoad(canvas); 

                
                if (DataBase.CanvasObjects.ContainsKey($"canvas{i}") && !canvas.Resources.Contains("taken"))
                {
                    canvas.Resources.Add("taken", true);
                }
            }


        }

        #endregion


        #region Proveri vrednost generatora-vrednosti van opsega  i LINIJE

        
        /// <param name="canvas"></param>

        private void ProveriVrednost(Canvas canvas)
        {
            foreach (Generator generator in DataBase.Generatori)
            {
                temp[generator.ID] = generator;
            }

            Task.Delay(2000).ContinueWith(_ =>
            {
                Application.Current.Dispatcher.Invoke(() =>
                {
                    if (DataBase.CanvasObjects.Count != 0)
                    {
                        if (DataBase.CanvasObjects.ContainsKey(canvas.Name))
                        {
                            bool ret = false;
                            foreach (var item in DataBase.Generatori)
                            {
                                if (item.ID == temp[DataBase.CanvasObjects[canvas.Name].ID].ID)
                                    ret = true;
                            }

                            if (!ret)
                                DataBase.CanvasObjects.Remove(canvas.Name);
                            else if (temp[DataBase.CanvasObjects[canvas.Name].ID].Vrednost < 1 || temp[DataBase.CanvasObjects[canvas.Name].ID].Vrednost > 5)
                            {
                                ((Border)(canvas).Children[0]).BorderBrush = Brushes.Red;
                                ((Border)(canvas).Children[0]).BorderThickness = new Thickness(100);
                                if (((Border)(canvas).Children[0]).BorderBrush.IsFrozen)
                                {
                                    ((Border)(canvas).Children[0]).BorderBrush = ((Border)(canvas).Children[0]).BorderBrush.Clone();
                                }
                                ((Border)(canvas).Children[0]).BorderBrush.Opacity = 0.5;
                            }
                            else
                                ((Border)(canvas).Children[0]).BorderBrush = Brushes.Transparent;
                        }
                        else
                            ((Border)(canvas).Children[0]).BorderBrush = Brushes.Transparent;
                    }
                });
                ProveriVrednost(canvas);
            });
        }

        //POVEZIVANJE LINIJOM CRVENOM
        /// <param name="canvases"></param>

        private void ConnectCanvasesWithOneLine(List<Canvas> canvases)
        {
            Grid grid = (Grid)CurrentUserControl.FindName("MainGrid");

            
            var existingLines = grid.Children.OfType<Line>().ToList(); //ovde se proveravaju postojece linije
            foreach (var line in existingLines)
            {
                grid.Children.Remove(line);
            }

            for (int i = 0; i < canvases.Count - 1; i++)
            {
                Canvas canvas1 = canvases[i];
                Canvas canvas2 = canvases[i + 1];

                
                Point canvas1Pos = canvas1.TransformToAncestor(grid).Transform(new Point(0, 0));
                Point canvas2Pos = canvas2.TransformToAncestor(grid).Transform(new Point(0, 0));

                //Tacna mozicija centra kanvasa
                Point canvas1Center = new Point(canvas1Pos.X + canvas1.ActualWidth / 2, canvas1Pos.Y + canvas1.ActualHeight / 2);
                Point canvas2Center = new Point(canvas2Pos.X + canvas2.ActualWidth / 2, canvas2Pos.Y + canvas2.ActualHeight / 2);

                
                Line line = new Line
                {
                    X1 = canvas1Center.X,
                    Y1 = canvas1Center.Y,
                    X2 = canvas2Center.X,
                    Y2 = canvas2Center.Y,
                    Stroke = Brushes.Yellow,
                    StrokeThickness = 2,
                    StrokeStartLineCap = PenLineCap.Round,
                    StrokeEndLineCap = PenLineCap.Round,
                    IsHitTestVisible = false
                };

               
                grid.Children.Add(line);
            }
        }

        #endregion
    }

       
}
