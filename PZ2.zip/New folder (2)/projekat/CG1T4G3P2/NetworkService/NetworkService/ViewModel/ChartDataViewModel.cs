﻿using NetworkService.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls.Primitives;
using System.Xml.Linq;

namespace NetworkService.ViewModel
{

    public class ChartDataViewModel : BindableBase
    {
        public MyICommand<CheckBoxData> CheckboxCommand { get; set; }
      

        private bool isChecked = true;
        public bool IsChecked
        {
            get { return isChecked; }
            set
            {
                isChecked = value;
                OnPropertyChanged("IsChecked");
            }
        }

        public static ObservableCollection<CheckBoxData> CheckBoxItems { get; set; } = new ObservableCollection<CheckBoxData>();

        public static ObservableCollection<Generator> ChartGenerators { get; set; } = new ObservableCollection<Generator>(); 

        public static GraphUpdater Elements { get; set; } = new GraphUpdater(); //elementi iz modela

      
        /// <param name="dot">Poluprecnik kruga</param>
        /// <param name="value">Vrednost</param>
        /// <param name="name">Koji generator menja vrednost</param>

        public static void SetFirstDotAndValue(double dot, double value, string name)
        {
            if(ChartGenerators.Count != 0)
            {
                var generator = ChartGenerators.FirstOrDefault(g => g.Naziv == name);

                if (generator != null)
                {
                    Elements.FirstDot = dot;
                    Elements.FirstValue = value;
                    Elements.FirstTime = DateTime.Now.ToString("HH:mm");
                }
            }
            else
            {
                Elements.FirstDot = dot;
                Elements.FirstValue = value;
                Elements.FirstTime = DateTime.Now.ToString("HH:mm");
            }
             
        }

       
        /// <param name="checkBoxData"></param>

        private void CheckBoxExecute(CheckBoxData checkBoxData)
        {
            Generator forDisplay = new Generator();

            if (checkBoxData.IsChecked)
            {
                var generator = DataBase.Generatori.FirstOrDefault(g => g.Naziv == checkBoxData.Naziv);
                ChartGenerators.Add(generator);
            }
            else
            {
                var generator = DataBase.Generatori.FirstOrDefault(g => g.Naziv == checkBoxData.Naziv);
                ChartGenerators.Remove(generator);
            }
  
        }

        
        /// <param name="value">Vrednost iz metering simulatora</param>
        /// <returns></returns>

        public static double CalculateElementRadius(double value)
        {
            return value * 8;  //Da bude srazmerno s gridom
        }

        //Inicijalizacija svih gen i komandi

        public ChartDataViewModel()
        {
            CheckboxCommand = new MyICommand<CheckBoxData>(CheckBoxExecute);

            CheckBoxItems.Clear();
            ChartGenerators.Clear();
            foreach (Generator ob in DataBase.Generatori)
            {
                CheckBoxItems.Add(new CheckBoxData(ob.Naziv, false));
            }
        }


    }
}
