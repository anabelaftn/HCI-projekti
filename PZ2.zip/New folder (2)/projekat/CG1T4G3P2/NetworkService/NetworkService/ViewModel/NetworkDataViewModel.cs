﻿using NetworkService.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using static NetworkService.Model.Generator;
using static NetworkService.Model.DataBase;
using System.ComponentModel;
using System.Threading;

namespace NetworkService.ViewModel
{
    public class NetworkDataViewModel : ValidationBase
    {
        public MyICommand AddCommand { get; set; }
        public MyICommand DeleteCommand { get; set; }

        public MyICommand FilterCommand { get; set; }

        public MyICommand ResetCommand { get; set; }

        public MyICommand SaveFilterCommand { get; set; }
        public MyICommand LoadFilterCommand { get; set; }

        public static ObservableCollection<Generator> GeneratorFilter { get; private set; } = new ObservableCollection<Generator>();

        private string pathFirst = "pack://application:,,,/Slike/SolarPanels.jpg";
        private string pathSecond = "pack://application:,,,/Slike/WindPowers.jpg";

        public NetworkDataViewModel()
        {
            NameValid = GetDefaultName();
            IdValid = GetNextId().ToString();

            PathValid = "pack://application:,,,/Slike/transparent.jpg";
            ValueName = true;
            NameOrType = 0;

            AddCommand = new MyICommand(OnAdd);
            DeleteCommand = new MyICommand(OnDelete, CanDelete);

            foreach (var generator in DataBase.Generatori)
            {
                Generators.Add(generator);
            }

            FilterCommand = new MyICommand(FilterNew);
            ResetCommand = new MyICommand(Reset);
            SaveFilterCommand = new MyICommand(SaveFilter);
            LoadFilterCommand = new MyICommand(LoadFilter);
        }

        public static List<string> TipoviComboBox { get; set; } = new List<string> { "Solarni Panel", "Vetro Generator" };

        private ObservableCollection<string> savedFiltersBox = new ObservableCollection<string>();

        public ObservableCollection<string> SavedFiltersBox
        {
            get { return savedFiltersBox; }
            set
            {
                if (savedFiltersBox != value)
                {
                    savedFiltersBox = value;
                    OnPropertyChanged(nameof(SavedFiltersBox));
                }
            }
        }


        /// Ucitavanje snimljenih filtera iz Snimljeni filteri
        

        private void LoadFilter()
        {
            if(SelectedSavedFilter != null)
            {
                string[] filterParts = SelectedSavedFilter.Split(';');

                if (filterParts.Length >= 3)
                {
                    FilterText = filterParts[0];
                    if (filterParts[1] == "")
                    {
                        SelectedFilterTip = null;
                    }
                    else
                    {
                        SelectedFilterTip = filterParts[1];
                    }
                    string filterType = filterParts[2];

                    
                    Lower = filterType == "Lower";
                    Higher = filterType == "Higher";
                    Equal = filterType == "Equal";
                }
            }
        }

        
        /// Snima filtere koji su izabrani u combobox Snimljeni filteri
       
        private void SaveFilter()
        {
            if (string.IsNullOrEmpty(FilterText) && string.IsNullOrEmpty(SelectedFilterTip))
            {
                return;
            }

            string filterType;
            if (Lower)
                filterType = "Lower";
            else if (Higher)
                filterType = "Higher";
            else if (Equal)
                filterType = "Equal";
            else
                filterType = string.Empty;

            string savedFilter = $"{FilterText};{SelectedFilterTip};{filterType}";
            SavedFiltersBox.Add(savedFilter);
        }

        
        /// Resetujem izabrane filtere i tabelu
        

        private void Reset()
        {
            FilterText = "";
            SelectedFilterTip = null; 
            Lower = true;
            Higher = false;
            Equal = false;

            Generators.Clear();
            foreach (var item in DataBase.Generatori)
            {
                Console.WriteLine(item.ID);
                Generators.Add(item);
            }

            OnPropertyChanged(nameof(Generators));
        }


        
        /// Na osnovu izabranih parametara za filtraciju prikazuje Generatore koji ih ispunjavaju
        

        private void FilterNew()
        { 

            if (string.IsNullOrEmpty(FilterText) && (string.IsNullOrEmpty(SelectedFilterTip) || SelectedFilterTip == null))
            {
                Generators.Clear();
                foreach (var item in DataBase.Generatori)
                {
                    Generators.Add(item);
                }
                return;
            }

            GeneratorFilter.Clear();

            if (FilterText != "")   
            {
                
                if (Lower)  
                {

                    for (int i = 0; i < DataBase.Generatori.Count; i++)   
                    {
                        if (DataBase.Generatori[i].ID < Convert.ToInt32(FilterText)) 
                        {
                            GeneratorFilter.Add(DataBase.Generatori[i]);   
                        }

                    }
                }
                else if (Equal){

                    for(int i = 0; i < DataBase.Generatori.Count; i++)
                    {
                        if(DataBase.Generatori[i].ID == Convert.ToInt32(FilterText))
                        {
                            GeneratorFilter.Add(DataBase.Generatori[i]);
                        }
                    }
                }
                else 
                {

                    for (int i = 0; i < DataBase.Generatori.Count; i++)
                    {
                        if (DataBase.Generatori[i].ID > Convert.ToInt32(FilterText))
                        {
                            GeneratorFilter.Add(DataBase.Generatori[i]);
                        }

                    }
                }

                if (SelectedFilterTip != "" && SelectedFilterTip != null) 
                {
                    foreach (var r in GeneratorFilter.ToList()) 
                    {
                        if (SelectedFilterTip != r.Tip.NazivTipa) 
                        {
                            GeneratorFilter.Remove(r);
                        }
                    }

                }


            }
            else  //samo za tipove-solar ili vetro
            {
                if (SelectedFilterTip != null)
                {
                    for (int i = 0; i < DataBase.Generatori.Count; i++)
                    {
                        if (SelectedFilterTip == DataBase.Generatori[i].Tip.NazivTipa)
                            GeneratorFilter.Add(DataBase.Generatori[i]);
                    }
                }
            }

            Generators.Clear();
            foreach (var r in GeneratorFilter.ToList())
            {
                
                Generators.Add(r);
            }

            foreach (var item in Generators)
            {
                Console.WriteLine("naziv: " + item.Naziv);
                Console.WriteLine("Id: " + item.ID);
            }

            OnPropertyChanged(nameof(Generators));
        }

        private static bool lower = true;
        private static bool higher = false;
        private static bool equal = false;

        public bool Lower
        {
            get { return lower; }
            set
            {
                if (lower != value)
                {
                    lower = value;
                    OnPropertyChanged("Lower");
                }
            }
        }
        public bool Higher
        {
            get { return higher; }
            set
            {
                if (higher != value)
                {
                    higher = value;
                    OnPropertyChanged("Higher");
                }
            }
        }

        public bool Equal
        {
            get { return equal; }
            set
            {
                if (equal != value)
                {
                    equal = value;
                    OnPropertyChanged("Equal");
                }
            }
        }

        private string filterText;
        public string FilterText   //ID po kom filtriram
        {
            get { return filterText; }
            set
            {
                if (filterText != value)
                {
                    filterText = value;
                    OnPropertyChanged("FilterText");
                }
            }
        }

        private string selectedFilterTip = string.Empty;

        public string SelectedFilterTip    //tip koji sam izabrala u comboboxu
        {
            get { return selectedFilterTip; }
            set
            {
                if (selectedFilterTip != value)
                {
                    selectedFilterTip = value;


                    OnPropertyChanged("SelectedFilterTip");
                }
            }
        }

        private string selectedSavedFilter = string.Empty;

        public string SelectedSavedFilter    //tip koji sam izabrala iz sacuvnaih filtera
        {
            get { return selectedSavedFilter; }
            set
            {
                if (selectedSavedFilter != value)
                {
                    selectedSavedFilter = value;


                    OnPropertyChanged("SelectedSavedFilter");
                }
            }
        }

        #region Generator Propeties


        private string idValid;
        public string IdValid
        {
            get { return idValid; }
            set
            {
                if (idValid != value)
                {
                    idValid = value;
                    OnPropertyChanged("IdValid");
                    UpdateNameIfDefault();
                }
            }
        }

        private string nameValid;
        public string NameValid
        {
            get { return nameValid; }
            set
            {
                if (nameValid != value)
                {
                    nameValid = value;
                    OnPropertyChanged("NameValid");
                }
            }
        }


        private string tipValid;
        public string TipValid
        {
            get { return tipValid; }
            set
            {
                if (tipValid != value)
                {
                    tipValid = value;
                    OnPropertyChanged("TipValid");

                    if (value == "Solarni Panel")
                        PathValid = pathFirst;
                    else
                        PathValid = pathSecond;

                    OnPropertyChanged("PathValid");

                }
            }
        }

        private string pathValid;
        public string PathValid
        {
            get { return pathValid; }
            set
            {
                if (pathValid != value)
                {
                    pathValid = value;
                    OnPropertyChanged("PathValid");
                }
            }
        }

        #endregion


        #region Selected Generator

        private Generator selectedGenerator;

        public Generator SelectedGenerator
        {
            get { return selectedGenerator; }
            set
            {
                selectedGenerator = value;
                DeleteCommand.RaiseCanExecuteChanged();
            }
        }

        #endregion


        #region List of Generators

        private ObservableCollection<Generator> generators = new ObservableCollection<Generator>();

        public ObservableCollection<Generator> Generators
        {
            get { return generators; }
            set
            {
                generators = value;
                OnPropertyChanged(nameof(Generators));
            }
        }


        #endregion


        #region Add

       
        /// Dodavanje novog generatora u listu generatora
        

        private void OnAdd()
        {
            Validate();

            if (IsValid)
            {
                int IDSS = int.Parse(IdValid);

                DataBase.Generatori.Add(new Generator()
                {
                    ID = IDSS,
                    Naziv = NameValid,
                    Tip = DataBase.TipoviGeneratora.First(mt => mt.NazivTipa == TipValid),
                    Vrednost = 0
                });

                Generators.Add(new Generator()
                {
                    ID = IDSS,
                    Naziv = NameValid,
                    Tip = DataBase.TipoviGeneratora.First(mt => mt.NazivTipa == TipValid),
                    Vrednost = 0
                });

                IdValid = GetNextId().ToString();
                Reset();

                OnPropertyChanged(nameof(Generators));
            }
        }

        #endregion


        #region Delete

       
        /// Brisem izabrani generator iz liste
       

        private bool CanDelete()
        {
            return SelectedGenerator != null;
        }

        private void OnDelete()
        {
            DataBase.Generatori.Remove(SelectedGenerator);

            Generators.Remove(SelectedGenerator);

            Reset();
            OnPropertyChanged(nameof(Generators));
        }

        #endregion


        #region Validation

        
        /// Validnost 
        

        protected override void ValidateSelf()
        {
            int IDS = 0;
            int.TryParse(IdValid, out IDS);

            if (string.IsNullOrWhiteSpace(NameValid))
            {
                this.ValidationErrors["Naziv"] = "Unesite naziv";
            }

            if (string.IsNullOrWhiteSpace(IdValid))
            {
                this.ValidationErrors["ID"] = "Unesite ID";
            }
            else if (!int.TryParse(IdValid, out IDS))
            {
                this.ValidationErrors["ID"] = "Mora biti broj";
            }
            else if (DataBase.Generatori.FirstOrDefault(tp => tp.ID == IDS) != default)
            {
                this.ValidationErrors["ID"] = "ID vec postoji";
            }
            else if (IDS < 1)
            {
                this.ValidationErrors["ID"] = "Mora biti > 0";
            }

            if (TipValid == "System.Windows.Controls.ComboBoxItem: select" || TipValid == null)
            {
                this.ValidationErrors["Tip"] = "Izaberite tip";
            }
        }

        #endregion


        #region Filter Properties

        private string searchValueText;
        public string SearchValueText
        {
            get { return searchValueText; }
            set
            {
                searchValueText = value;
                OnPropertyChanged("SearchValueText");
                FilterCommand.RaiseCanExecuteChanged();
            }
        }

        private int nameOrType;
        public int NameOrType
        {
            get { return nameOrType; }
            set
            {
                nameOrType = value;
            }
        }

        private string nameButtonSearch = "Search";
        public string NameButtonSearch
        {
            get { return nameButtonSearch; }
            set
            {
                nameButtonSearch = value;
                OnPropertyChanged("NameButtonSearch");
            }
        }

        private bool valueName;
        public bool ValueName
        {
            get { return valueName; }
            set
            {
                valueName = value;
                OnPropertyChanged("ValueName");
            }
        }

        private bool valueType;
        public bool ValueType
        {
            get { return valueType; }
            set
            {
                valueType = value;
                OnPropertyChanged("ValueType");
            }
        }

        #endregion



        #region Update Name or ID

        #region NextID

        public static int GetNextId()
        {
            int nextId = 1;

            while (DataBase.Generatori.FirstOrDefault(gr => gr.ID == nextId) != default)
            {
                nextId++;
            }

            return nextId;
        }

        #endregion


        #region UpdateName

        private void UpdateNameIfDefault()
        {
            if (NameValid != null)
            {
                if (NameValid.Contains("Generator_"))
                {
                    NameValid = GetDefaultName();
                }
            }
        }

        #endregion


        #region DefaultName
        private string GetDefaultName()
        {
            return $"Generator_{IdValid}";
        }
        #endregion

        #endregion



    }
}
