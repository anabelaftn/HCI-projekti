﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace projekatPZ1
{
    #region potrebno
    public static class promenljive
    {
        private static string logovanjeUspeno;

        private static readonly string adminUsername = "jokic";
        private static readonly string korisnikUsername = "partizan";

        public static string LogovanjeUspesno
        {
            get => logovanjeUspeno; set => logovanjeUspeno = value;
        }

        public static string KorisnikUsername => korisnikUsername;

        public static string AdminUserName => adminUsername;
    }
    #endregion
    public partial class MainWindow : Window
    {

        #region sifre
        private readonly string adminSifra = "nba";
        private readonly string korisnikSifra = "najjaci";

        #endregion

        public MainWindow()
        {
            InitializeComponent();

            #region ukazivanje na unos
            textBoxIme.Text = "Unesite korisnicko ime ovde";
            textBoxIme.Foreground = Brushes.White;

            #endregion
        }

        #region GotFocus za textBoxIme
        private void textBoxIme_GotFocus(object sender, RoutedEventArgs e)
        {

            if (textBoxIme.Text.Trim().Equals("Unesite korisnicko ime ovde"))
            {
                textBoxIme.Text = "";
                textBoxIme.Foreground = Brushes.White;
            }
        }

        #endregion

        #region LostFocus za textBoxIme
        private void textBoxIme_LostFocus(object sender, RoutedEventArgs e)
        {
            if (textBoxIme.Text.Trim().Equals(string.Empty))
            {
                textBoxIme.Text = "Unesite korisnicko ime ovde";
                textBoxIme.Foreground = Brushes.Gray;
            }
        }
        #endregion

        #region Validacija
        private bool Validate()
        {
            bool rez = true; //mora da bude Validate bool i da vrati tu neku vrednost

            if (textBoxIme.Text.Trim().Equals("") || textBoxIme.Text.Trim().Equals("Unesite korisnicko ime ovde"))
            {
                rez = false;  //Nije popunjeno, izbacuje gresku
                textBoxIme.BorderBrush = Brushes.DarkRed;
                textBoxIme.BorderThickness = new Thickness(2);
                MessageBox.Show("!!!Morate prvo popuniti Username!!!", "---GRESKA------------------------", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else
            {
                textBoxIme.BorderBrush = Brushes.White;  //SVe u redu
                textBoxIme.BorderThickness = new Thickness(2);
            }

            if (passworBoxLozinka.Password.Trim().Equals(""))
            {
                rez = false;
                passworBoxLozinka.BorderBrush = Brushes.DarkRed;
                passworBoxLozinka.BorderThickness = new Thickness(2);
                MessageBox.Show("!!!Morate prvo popuniti Password!!!", "---GRESKA------------------------", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else
            {
                passworBoxLozinka.BorderBrush = Brushes.Gray;
                passworBoxLozinka.BorderThickness = new Thickness(1);
            }

            if (!(textBoxIme.Text.Trim().Equals(promenljive.AdminUserName) && passworBoxLozinka.Password.Trim().Equals(adminSifra))
                && !(textBoxIme.Text.Trim().Equals(promenljive.KorisnikUsername) && passworBoxLozinka.Password.Trim().Equals(korisnikSifra)))
            {
                //Ovde proveram ako korisnik ili admin nisu uneli zakucanu sifru i usern

                rez = false;
                textBoxIme.BorderBrush = Brushes.DarkRed;
                textBoxIme.BorderThickness = new Thickness(2);
                passworBoxLozinka.BorderBrush = Brushes.DarkRed;
                passworBoxLozinka.BorderThickness = new Thickness(3);
                textBoxIme.Text = "Unesite korisnicko ime ovde";
                textBoxIme.Foreground = Brushes.Gray;
                passworBoxLozinka.Password = " ";
                MessageBox.Show("!!!Greska prilikom unosa!!!", "---GRESKA------------------------", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else
            {
                textBoxIme.BorderBrush = Brushes.White;
                textBoxIme.BorderThickness = new Thickness(2);

                passworBoxLozinka.BorderBrush = Brushes.White;
                passworBoxLozinka.BorderThickness = new Thickness(2);
            }

            return rez;
        }
        #endregion

        #region dugmePrijava
        private void buttonPrijava_Click(object sender, RoutedEventArgs e)
        {
            if (Validate())
            {
                if (textBoxIme.Text.Equals(promenljive.AdminUserName) && passworBoxLozinka.Password.Equals(adminSifra))
                {
                    promenljive.LogovanjeUspesno = textBoxIme.Text;
                    MessageBox.Show("Logovanje admina...", "", MessageBoxButton.OK, MessageBoxImage.Information);  //prozorcic

                    //prelazak na sledeci prozor
                    DodajWindow dodajWindow = new DodajWindow();
                    dodajWindow.ShowDialog();
                }
                else if (textBoxIme.Text.Equals(promenljive.KorisnikUsername) && passworBoxLozinka.Password.Equals(korisnikSifra))
                {
                    promenljive.LogovanjeUspesno = textBoxIme.Text;
                    MessageBox.Show("Logovanje korisnika...", "", MessageBoxButton.OK, MessageBoxImage.Information); //prozorcic

                    //prelazak na sledeci prozor
                    DodajWindow dw = new DodajWindow();
                    dw.ShowDialog();
                }
            }

        }
        #endregion


        #region dugmeIzlaz
        private void buttonIzlaz_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
        #endregion
    }
}
