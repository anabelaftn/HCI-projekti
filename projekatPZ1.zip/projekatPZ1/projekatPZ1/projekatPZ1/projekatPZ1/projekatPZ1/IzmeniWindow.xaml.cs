﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace projekatPZ1
{
    /// <summary>
    /// Interaction logic for izmenaIgraca.xaml
    /// </summary>
    public partial class IzmeniWindow : Window
    {
        private static int i = 0;
        private static string izmena = "";
        private static string fajl2 = "";
        private static string slika2 = "";

        public IzmeniWindow(int selectedIndex)
        {
            InitializeComponent();


            Igraci igrac = DodajWindow.Igrac[i];
            i = selectedIndex;

            bojaSlova.SelectedIndex = 0;
            textboxSlika.Text = "";
            textboxSlika.Visibility = Visibility.Hidden;

            velicinaSlova.ItemsSource = new List<double>() { 6, 8, 9, 10, 11, 12, 14, 16, 18, 20, 22, 24, 26, 28, 30 }; //lista velciina slova
            izborFonta.ItemsSource = Fonts.SystemFontFamilies.OrderBy(f => f.Source);  //font iz familije fontova, poredjani lepo
            bojaSlova.SelectedIndex = 0;  //nijedna nije selektovana boja
            bojaSlova.ItemsSource = new List<string>() { "Black", "White", "Blue", "Red", "Green", "Yellow", "Gray", "Pink", "Brown", "Purple" };


            //slika
            slika2 = igrac.Slika;
            Uri uri = new Uri(igrac.Slika);
            imgSlika.Source = new BitmapImage(uri);

            //Fajl
            fajl2 = igrac.Fajl;

            //tb za sve
            textic.Text = igrac.Klub;
            textboxIme.Text = igrac.Ime;
            textboxPrezime.Text = igrac.Prezime;
            textboxGodiste.Text = igrac.GodinaRodjenja.ToString();
            textboxUtakmice.Text = igrac.BrojUtakmica.ToString();
            textboxPoeni.Text = igrac.BrojUtakmica.ToString();




            TextRange textRange; //opseg reci
            System.IO.FileStream fileStream; //za koriscenje fajla

            if (System.IO.File.Exists(fajl2))
            {
                textRange = new TextRange(richtext.Document.ContentStart, richtext.Document.ContentEnd); //Od pocetka do kraja

                using (fileStream = new System.IO.FileStream(fajl2, System.IO.FileMode.OpenOrCreate))
                {
                    textRange.Load(fileStream, System.Windows.DataFormats.Rtf);
                }
                textic.Text = textRange.Text;
            }
        }

        private void izborFonta_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            if (izborFonta.SelectedItem != null)
            {
                richtext.Selection.ApplyPropertyValue(Inline.FontFamilyProperty, izborFonta.SelectedItem); //selektovani tekst u rb ce dobiti novi font
            }
        }

        private void velicinaSlova_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (velicinaSlova.SelectedValue != null)
            {
                richtext.Selection.ApplyPropertyValue(Inline.FontSizeProperty, velicinaSlova.SelectedValue); //ovde menjamo velicinu, value jer je int size
            }
        }

        private void bojaSlova_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (bojaSlova.SelectedValue != null)
            {
                richtext.Selection.ApplyPropertyValue(Inline.ForegroundProperty, bojaSlova.SelectedValue);
            }
        }




        private void richtext_SelectionChanged(object sender, RoutedEventArgs e)
        {
            
            object izmena = richtext.Selection.GetPropertyValue(Inline.TextDecorationsProperty);
            uiDugme.IsChecked = (izmena != DependencyProperty.UnsetValue) && (izmena.Equals(TextDecorations.Underline));

            izmena = richtext.Selection.GetPropertyValue(Inline.FontWeightProperty);
            boldDugme.IsChecked = (izmena != DependencyProperty.UnsetValue) && (izmena.Equals(FontWeights.Bold));

            izmena = richtext.Selection.GetPropertyValue(Inline.FontStyleProperty); //ovdd se nesto izabere
            italicDugme.IsChecked = (izmena != DependencyProperty.UnsetValue) && (izmena.Equals(FontStyles.Italic)); //proveraava se razlicitost od null i da li je cekirano to dugme italic npr

            izmena = richtext.Selection.GetPropertyValue(Inline.FontFamilyProperty);
            izborFonta.SelectedItem = izmena;

            izmena = richtext.Selection.GetPropertyValue(Inline.FontSizeProperty);
            velicinaSlova.Text = izmena.ToString();


        }

        //funkcija za prebrojavanje reci u richu

        private void prebrojavanjeReci()
        {

            string tekst = new TextRange(richtext.Document.ContentStart, richtext.Document.ContentEnd).Text;

            int br = tekst.Split(new char[] { ' ', ',', '.' }, StringSplitOptions.RemoveEmptyEntries).Length;

            brojac.Text = br.ToString();

        }

        private void richtext_TextChanged(object sender, System.Windows.Controls.TextChangedEventArgs e)
        {
            prebrojavanjeReci();
        }

        private void pretragaSlike_Click(object sender, RoutedEventArgs e)
        {
            textboxSlika.Visibility = Visibility.Hidden;
            textboxSlika.Text = "";
            OpenFileDialog openFileDialog = new OpenFileDialog(); //iskoci prozorcic za sliku tj za njen odabir
            if (openFileDialog.ShowDialog() == true)
            {
                izmena = openFileDialog.FileName; //putanja do elementa u dijalogu tom
                Uri link = new Uri(izmena);
                imgSlika.Source = new BitmapImage(link);
                textboxSlika.Visibility = Visibility.Hidden;
                textboxSlika.Text = "";
            }
        }

        private void dataDatum_MouseEnter(object sender, MouseEventArgs e)
        {


            dateDatum.Text = DateTime.Now.ToString();

            dateDatum.IsEnabled = false; //posto smo izabrali onemoguceno je

        }

        private void buttonIzlaz_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }




        private bool Validate()
        {
            bool rez = true;

            //provera za richtext za klubove

            if (richtext.ToString().Trim().Equals(string.Empty))
            {
                rez = false;
                richtext.BorderBrush = Brushes.Red;
                richtext.BorderThickness = new Thickness(2);
                MessageBox.Show("Morate popuniti polje KLUBOVI!", "--GRESKA-------------------", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else
            {
                richtext.BorderBrush = Brushes.LightGreen;
                richtext.BorderThickness = new Thickness(2);
            }

            //provera za tb za ime

            if (textboxIme.Text.Trim().Equals(""))
            {
                rez = false;
                textboxIme.BorderBrush = Brushes.Red;
                textboxIme.BorderThickness = new Thickness(2);
                MessageBox.Show("Ime igraca MORA biti popunjeno!", "--GRESKA-----------------------", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else
            {
                textboxIme.BorderBrush = Brushes.LightGreen;
                textboxIme.BorderThickness = new Thickness(2);
            }

            //provera za tb za prezime

            if (textboxPrezime.Text.Trim().Equals(""))
            {
                rez = false;
                textboxPrezime.BorderBrush = Brushes.Red;
                textboxPrezime.BorderThickness = new Thickness(2);
                MessageBox.Show("Prezime igraca MORA biti popunjeno!", "--GRESKA------------------", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else
            {
                textboxPrezime.BorderBrush = Brushes.LightGreen;
                textboxPrezime.BorderThickness = new Thickness(2);
            }

            //Godiste igraca

            if (textboxGodiste.Text.Trim().Equals(""))
            {
                rez = false;
                textboxGodiste.BorderBrush = Brushes.Red;
                textboxGodiste.BorderThickness = new Thickness(2);
                MessageBox.Show("Godiste igraca MORA biti popunjeno!", "--GRESKA-------------------", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else
            {
                textboxGodiste.BorderBrush = Brushes.LightGreen;
                textboxGodiste.BorderThickness = new Thickness(2);
            }

            var ispravnost = Int64.TryParse(textboxGodiste.Text, out _);  //parsiramo string u int i onda proveravamo sta je izlazna vrednost unutar te metode(out _)
            if (!ispravnost)
            {
                rez = false;
                textboxGodiste.BorderBrush = Brushes.Red;
                textboxGodiste.BorderThickness = new Thickness(2);
                MessageBox.Show("Godiste igraca MORA biti broj!", "--GRESKA-------------", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else
            {
                if (Int64.Parse(textboxGodiste.Text) < 1900 || Int64.Parse(textboxGodiste.Text) > 2005) //2005 zato sto igraci u NBA igraci moraju imati 19 god najmanje zbog koledza
                {
                    rez = false;
                    textboxGodiste.BorderBrush = Brushes.Red;
                    textboxGodiste.BorderThickness = new Thickness(2);
                    MessageBox.Show("Godiste nije pravilno uneseno!", "--GRESKA-------------", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                else
                {
                    textboxGodiste.BorderBrush = Brushes.LightGreen;
                    textboxGodiste.BorderThickness = new Thickness(2);
                }
            }


            //Broj poena
            if (textboxPoeni.Text.Trim().Equals(""))
            {
                rez = false;
                textboxPoeni.BorderBrush = Brushes.Red;
                textboxPoeni.BorderThickness = new Thickness(2);
                MessageBox.Show("Poeni igraca MORAJU biti popunjeni!", "--GRESKA-------------------", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else
            {
                textboxPoeni.BorderBrush = Brushes.LightGreen;
                textboxPoeni.BorderThickness = new Thickness(2);
            }

            bool ispravnost1 = Int64.TryParse(textboxPoeni.Text, out _);  //parsiramo string u int i onda proveravamo sta je izlazna vrednost unutar te metode(out _)
            if (ispravnost1 == false)
            {
                rez = false;
                textboxPoeni.BorderBrush = Brushes.Red;
                textboxPoeni.BorderThickness = new Thickness(3);
                MessageBox.Show("Poeni igraca MORAJU biti broj!", "--GRESKA-------------", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else
            {
                if (Int64.Parse(textboxPoeni.Text) < 0)
                {
                    rez = false;
                    textboxPoeni.BorderBrush = Brushes.Red;
                    textboxPoeni.BorderThickness = new Thickness(2);
                    MessageBox.Show("Poeni NE MOGU biti negativni!", "--GRESKA-------------", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                else
                {
                    textboxPoeni.BorderBrush = Brushes.LightGreen;
                    textboxPoeni.BorderThickness = new Thickness(2);
                }
            }

            //Broj utakmica
            if (textboxUtakmice.Text.Trim().Equals(""))
            {
                rez = false;
                textboxUtakmice.BorderBrush = Brushes.Red;
                textboxUtakmice.BorderThickness = new Thickness(2);
                MessageBox.Show("Utakmice igraca MORAJU biti popunjene!", "--GRESKA-------------------", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else
            {
                textboxUtakmice.BorderBrush = Brushes.LightGreen;
                textboxUtakmice.BorderThickness = new Thickness(2);
            }

            bool ispravnost2 = Int64.TryParse(textboxUtakmice.Text, out _);  //parsiramo string u int i onda proveravamo sta je izlazna vrednost unutar te metode(out _)
            if (ispravnost2 == false)
            {
                rez = false;
                textboxUtakmice.BorderBrush = Brushes.Red;
                textboxUtakmice.BorderThickness = new Thickness(3);
                MessageBox.Show("Utakmice igraca MORAJU biti broj!", "--GRESKA-------------", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else
            {
                if (Int64.Parse(textboxPoeni.Text) < 0)
                {
                    rez = false;
                    textboxUtakmice.BorderBrush = Brushes.Red;
                    textboxUtakmice.BorderThickness = new Thickness(2);
                    MessageBox.Show("Utakmice NE MOGU biti negativne!", "--GRESKA-------------", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                else
                {
                    textboxUtakmice.BorderBrush = Brushes.LightGreen;
                    textboxUtakmice.BorderThickness = new Thickness(2);
                }
            }

            //slike

            if (textboxSlika.Text.Equals("Slika"))
            {
                rez = false;
                textboxSlika.BorderBrush = Brushes.Red;
                textboxSlika.BorderThickness = new Thickness(2);
                MessageBox.Show("Morate postaviti sliku!", "--GRESKA---------------", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else
            {
                textboxSlika.BorderBrush = Brushes.LightGreen;
                textboxSlika.BorderThickness = new Thickness(2);
            }

            //datum

            if (dateDatum.Text.Equals("") || dateDatum.Text.Equals("Select a date"))
            {
                rez = false;
                dateDatum.BorderBrush = Brushes.Red;
                dateDatum.BorderThickness = new Thickness(2);
                MessageBox.Show("Datum MORA biti izabran!", "--GRESKA-----------------", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else
            {
                dateDatum.BorderBrush = Brushes.LightGreen;
                dateDatum.BorderThickness = new Thickness(2);
            }

            return rez;
        }

        private void buttonIymeni_Click(object sender, RoutedEventArgs e)
        {
            if (Validate())
            {
                if (izmena == "")
                {
                    izmena = slika2;
                }

                TextRange textRange;
                FileStream fileStream;
                textRange = new TextRange(richtext.Document.ContentStart, richtext.Document.ContentEnd);
                fileStream = new FileStream(fajl2, FileMode.Open);
                textRange.Save(fileStream, DataFormats.Rtf);
                fileStream.Close();

                TextRange pom; //opseg reci
                System.IO.FileStream fStream; //za koriscenje fajla

                if (System.IO.File.Exists(fajl2))
                {
                    pom = new TextRange(richtext.Document.ContentStart, richtext.Document.ContentEnd); //Od pocetka do kraja

                    using (fStream = new System.IO.FileStream(fajl2, System.IO.FileMode.OpenOrCreate))
                    {
                        pom.Load(fStream, System.Windows.DataFormats.Rtf);
                    }
                    textic.Text = pom.Text;
                }

                DodajWindow.Igrac[i] = (new Igraci(textic.Text, textboxIme.Text, textboxPrezime.Text, Int64.Parse(textboxGodiste.Text), Int64.Parse(textboxPoeni.Text), Int64.Parse(textboxUtakmice.Text), izmena, fajl2, DateTime.Now));
                izmena = "";

                this.Close();
            }
        }
    }
}
